<?php
class Type extends AppModel {

	var $name = 'Type';

}
?>