<?php
class AppController extends Controller {
	//var $components = array('Auth');
    var $helpers=array('Html','Form','Javascript','Fck');
}
?>