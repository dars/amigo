<?php
class DepartmentsController extends AppController {

	var $name = 'Departments';
	var $uses=array('Department','School','Category');
	
	function index() {
		$this->Department->recursive = 0;
		$conditions=array();
		if(!empty($this->params['url']['school'])){
			$conditions['School.id']=$this->params['url']['school'];
		}
		if(!empty($this->params['url']['category'])){
			$conditions['Category.id']=$this->params['url']['category'];
		}
		$this->paginate=array('conditions'=>$conditions);
		$this->set('departments', $this->paginate());
		$this->set('school',$this->School->find('list'));
		$this->set('category',$this->Category->find('list'));
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Department.', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->set('department', $this->Department->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Department->create();
			if ($this->Department->save($this->data)) {
				$this->Session->setFlash(__('The Department has been saved', true));
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The Department could not be saved. Please, try again.', true));
			}
		}
		$schools = $this->Department->School->find('list');
		$categories = $this->Department->Category->find('list');
		$this->set(compact('schools', 'categories'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Department', true));
			$this->redirect(array('action'=>'index'));
		}
		if (!empty($this->data)) {
			if ($this->Department->save($this->data)) {
				$this->Session->setFlash(__('The Department has been saved', true));
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The Department could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Department->read(null, $id);
		}
		$schools = $this->Department->School->find('list');
		$categories = $this->Department->Category->find('list');
		$this->set(compact('schools','categories'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Department', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Department->del($id)) {
			$this->Session->setFlash(__('Department deleted', true));
			$this->redirect(array('action'=>'index'));
		}
	}

}
?>