<?php
class SchoolsController extends AppController {

	var $name = 'Schools';

	function index() {
		$this->School->recursive = 0;
		$this->set('schools', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash('不正確的參數');
			$this->redirect(array('action'=>'index'));
		}
		//$this->set('school', $this->School->read(null, $id));
		$this->set('school', $this->School->find('first',array(
			'conditions'=>array('School.id'=>$id),
			'recursive'=>2
		)));
	}

	function add() {
		if (!empty($this->data)) {
			$this->School->create();
			if ($this->School->save($this->data)) {
				$this->Session->setFlash('資料已新增');
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The School could not be saved. Please, try again.', true));
			}
		}
		$types = $this->School->Type->find('list');
		$this->set(compact('types'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('不正確的參數');
			$this->redirect(array('action'=>'index'));
		}
		if (!empty($this->data)) {
			if ($this->School->save($this->data)) {
				$this->Session->setFlash('資料已儲存');
				$this->redirect(array('action'=>'index'));
			} else {
				$this->Session->setFlash(__('The School could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->School->read(null, $id);
		}
		$types = $this->School->Type->find('list');
		$this->set(compact('types'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash('不正確的參數');
			$this->redirect(array('action'=>'index'));
		}
		if ($this->School->del($id)) {
			$this->Session->setFlash('資料已刪除');
			$this->redirect(array('action'=>'index'));
		}
	}

}
?>